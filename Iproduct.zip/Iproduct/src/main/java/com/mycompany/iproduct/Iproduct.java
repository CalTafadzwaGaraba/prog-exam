/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.iproduct;

/**
 *
 * @author Cal Garaba
 */

public interface Iproduct {
    int TotalSales(int[][] mattressSales);
    double AverageSales(int[][] mattressSales);
    int MostPopular(int[][] mattressSales);
}

ProductSales.javaJavapublic class ProductSales implements IProduct {

    @Override
    public int TotalSales(int[][] productSales) {
        int total = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                total += sale;
            }
        }
        return total;
    }

    @Override
    public double AverageSales(int[][] productSales) {
        int total = TotalSales(productSales);
        int count = 0;
        for (int[] year : productSales) {
            count += year.length;
        }
        return (double) total / count;
    }

    @Override
    public int MaxSale(int[][] productSales) {
        int max = productSales[0][0];
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale > max) {
                    max = sale;
                }
            }
        }
        return max;
    }

    @Override
    public int MinSale(int[][] productSales) {
        int min = productSales[0][0];
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale < min) {
                    min = sale;
                }
            }
        }
        return min;
    }
}

public class ProductSalesApp {
    public static void main(String[] args) {
        int[][] salesData = {
            {300, 150, 700}, // Year 1: Q1, Q2, Q3
            {250, 200, 600}  // Year 2: Q1, Q2, Q3
        };

        ProductSales ps = new ProductSales();

        System.out.println("​Enter number of sales for month 1 for Cozy Nights Monarch mattress:");
        System.out.println("---------------------------");
        System.out.println("Total sales:   " + ps.TotalSales(salesData));
        System.out.println("Average sales: " + Math.round(ps.AverageSales(salesData)));
        System.out.println("Maximum sale:  " + ps.MaxSale(salesData));
        System.out.println("Minimum sale:  " + ps.MinSale(salesData));
        System.out.println("---------------------------");
    }
}
