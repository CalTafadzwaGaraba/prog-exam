/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.iproduct;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Cal Garaba
 */
public class IproductTest {
    
    public IproductTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of TotalSales method, of class Iproduct.
     */
    @org.junit.jupiter.api.Test
    public void testTotalSales() {
        System.out.println("TotalSales");
        int[][] productSales = null;
        Iproduct instance = new IproductImpl();
        int expResult = 0;
        int result = instance.TotalSales(productSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of AverageSales method, of class Iproduct.
     */
    @org.junit.jupiter.api.Test
    public void testAverageSales() {
        System.out.println("AverageSales");
        int[][] productSales = null;
        Iproduct instance = new IproductImpl();
        double expResult = 0.0;
        double result = instance.AverageSales(productSales);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MostPopular method, of class Iproduct.
     */
    @org.junit.jupiter.api.Test
    public void testMostPopular() {
        System.out.println("MostPopular");
        int[][] productSales = null;
        Iproduct instance = new IproductImpl();
        int expResult = 0;
        int result = instance.MostPopular(productSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IproductImpl implements Iproduct {

        public int TotalSales(int[][] productSales) {
            return 0;
        }

        public double AverageSales(int[][] productSales) {
            return 0.0;
        }

        public int MostPopular(int[][] productSales) {
            return 0;
        }
    }

    /**
     * Test of main method, of class Iproduct.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Iproduct.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
