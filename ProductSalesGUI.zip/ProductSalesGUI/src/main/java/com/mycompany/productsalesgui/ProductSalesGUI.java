/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author Cal Garaba
 */

package com.mycompany.productsalesgui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductSalesGUI extends JFrame implements ActionListener {
    //declaring variables and classes 
    private JLabel lblCustomer, lblProduct, lblSales;
    private JLabel lblVat, lblCommission, lblTotal;

    private JTextField txtCustomer;
    private JTextField txtProduct;
    private JTextField txtSales;

    private JButton btnProcess;

    private JTextArea txtReport;

    // to calculate product sales 
    public ProductSalesGUI() {

        setTitle("Product Sales Application");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Menu Bar and options 
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");

        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem clearItem = new JMenuItem("Clear");

        processItem.addActionListener(e -> calculateSales());
        saveItem.addActionListener(e -> saveData());
        clearItem.addActionListener(e -> clearData());

        toolsMenu.add(processItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Main Panel
        JPanel panel = new JPanel();
        panel.setLayout(null);

        // customer name panel
        lblCustomer = new JLabel("Customer Name:");
        lblCustomer.setBounds(20, 20, 120, 25);
        panel.add(lblCustomer);

        txtCustomer = new JTextField();
        txtCustomer.setBounds(150, 20, 200, 25);
        panel.add(txtCustomer);

        // Product Name Panel
        lblProduct = new JLabel("Product Name:");
        lblProduct.setBounds(20, 60, 120, 25);
        panel.add(lblProduct);

        txtProduct = new JTextField();
        txtProduct.setBounds(150, 60, 200, 25);
        panel.add(txtProduct);

        // Product Sales panel and calculations 
        lblSales = new JLabel("Product Sales:");
        lblSales.setBounds(20, 100, 120, 25);
        panel.add(lblSales);

        txtSales = new JTextField();
        txtSales.setBounds(150, 100, 200, 25);
        panel.add(txtSales);

        // Process Button
        btnProcess = new JButton("Process");
        btnProcess.setBounds(150, 140, 120, 30);
        btnProcess.addActionListener(this);
        panel.add(btnProcess);

        // Results
        lblVat = new JLabel("VAT Amount:");
        lblVat.setBounds(20, 190, 300, 25);
        panel.add(lblVat);

        lblCommission = new JLabel("Commission:");
        lblCommission.setBounds(20, 220, 300, 25);
        panel.add(lblCommission);

        lblTotal = new JLabel("Total Sales:");
        lblTotal.setBounds(20, 250, 300, 25);
        panel.add(lblTotal);

        // Report Area
        txtReport = new JTextArea();
        txtReport.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(txtReport);
        scrollPane.setBounds(20, 290, 540, 120);

        panel.add(scrollPane);

        add(panel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        calculateSales();
    }

    private void calculateSales() {

        try {

            String customer = txtCustomer.getText();
            String product = txtProduct.getText();

            double sales = Double.parseDouble(txtSales.getText());

            double vat = sales * 0.15;
            double commission = sales * 0.10;
            double totalSales = sales + vat;

            lblVat.setText("VAT Amount: R" + String.format("%.2f", vat));
            lblCommission.setText("Commission: R" + String.format("%.2f", commission));
            lblTotal.setText("Total Sales: R" + String.format("%.2f", totalSales));

            txtReport.setText(
                    "SALES REPORT\n" +
                    "=========================\n" +
                    "Customer: " + customer + "\n" +
                    "Product: " + product + "\n" +
                    "Sales Amount: R" + String.format("%.2f", sales) + "\n" +
                    "VAT (15%): R" + String.format("%.2f", vat) + "\n" +
                    "Commission (10%): R" + String.format("%.2f", commission) + "\n" +
                    "Total Sales: R" + String.format("%.2f", totalSales)
            );

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid sales amount.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void saveData() {

        try (PrintWriter writer =
                     new PrintWriter(new FileWriter("SalesReport.txt"))) {

            writer.println(txtReport.getText());

            JOptionPane.showMessageDialog(
                    this,
                    "Report saved successfully."
            );

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving file: " + ex.getMessage()
            );
        }
    }

    private void clearData() {

        txtCustomer.setText("");
        txtProduct.setText("");
        txtSales.setText("");

        lblVat.setText("VAT Amount:");
        lblCommission.setText("Commission:");
        lblTotal.setText("Total Sales:");

        txtReport.setText("");
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ProductSalesGUI().setVisible(true);
        });
    }
}